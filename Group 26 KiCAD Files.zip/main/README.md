# tp4056
TP4056 charger kicad schematics

Kicad version with tp4056 footprint and schematics

TP4056 Lithium Cell Charger Module with Battery Protection  without usb connector

Charging current set to 130ma (R=10kOm)


![Preview](https://github.com/alltheworld/tp4056/blob/master/out/charger_stepup1.jpg)

![Preview](https://github.com/alltheworld/tp4056/blob/master/out/charger_stepup2.jpg)

